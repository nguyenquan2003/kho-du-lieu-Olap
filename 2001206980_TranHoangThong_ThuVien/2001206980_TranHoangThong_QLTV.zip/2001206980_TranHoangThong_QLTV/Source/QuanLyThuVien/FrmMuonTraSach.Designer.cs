﻿namespace QuanLyThuVien
{
    partial class FrmMuonTraSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMaPhieuMuon = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbMaThe = new System.Windows.Forms.ComboBox();
            this.txtTimKiemSach = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSoLuongMuon = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbTenSach = new System.Windows.Forms.ComboBox();
            this.cbMaSach = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimeNT = new System.Windows.Forms.DateTimePicker();
            this.dateTimeNM = new System.Windows.Forms.DateTimePicker();
            this.cbTenTheLoai = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewPM = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewPhieuTra = new System.Windows.Forms.DataGridView();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbTinhTrangSach = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSoLuongDaMuon = new System.Windows.Forms.TextBox();
            this.txtSoLuongTra = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMaPhieuTra = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTimKiemTheTra = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimeNgayTra = new System.Windows.Forms.DateTimePicker();
            this.cbTenSachTra = new System.Windows.Forms.ComboBox();
            this.cbMaTheTra = new System.Windows.Forms.ComboBox();
            this.cbMaDocGia = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.btnXoaPhieuMuon = new System.Windows.Forms.Button();
            this.btnChoMuon = new System.Windows.Forms.Button();
            this.btnDong1 = new System.Windows.Forms.Button();
            this.btnXoaPhieuTra = new System.Windows.Forms.Button();
            this.btnTraSach = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPM)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPhieuTra)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SkyBlue;
            this.groupBox1.Controls.Add(this.txtMaPhieuMuon);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbMaThe);
            this.groupBox1.Controls.Add(this.txtTimKiemSach);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtSoLuongMuon);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cbTenSach);
            this.groupBox1.Controls.Add(this.cbMaSach);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dateTimeNT);
            this.groupBox1.Controls.Add(this.dateTimeNM);
            this.groupBox1.Controls.Add(this.cbTenTheLoai);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(22, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(816, 239);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cho mượn";
            // 
            // txtMaPhieuMuon
            // 
            this.txtMaPhieuMuon.Enabled = false;
            this.txtMaPhieuMuon.Location = new System.Drawing.Point(194, 205);
            this.txtMaPhieuMuon.Name = "txtMaPhieuMuon";
            this.txtMaPhieuMuon.Size = new System.Drawing.Size(195, 26);
            this.txtMaPhieuMuon.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(80, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 19);
            this.label9.TabIndex = 17;
            this.label9.Text = "Mã phiếu mượn";
            // 
            // cbMaThe
            // 
            this.cbMaThe.FormattingEnabled = true;
            this.cbMaThe.Location = new System.Drawing.Point(194, 118);
            this.cbMaThe.Name = "cbMaThe";
            this.cbMaThe.Size = new System.Drawing.Size(195, 27);
            this.cbMaThe.TabIndex = 16;
            // 
            // txtTimKiemSach
            // 
            this.txtTimKiemSach.Location = new System.Drawing.Point(544, 164);
            this.txtTimKiemSach.Name = "txtTimKiemSach";
            this.txtTimKiemSach.Size = new System.Drawing.Size(189, 26);
            this.txtTimKiemSach.TabIndex = 15;
            this.txtTimKiemSach.TextChanged += new System.EventHandler(this.txtTimKiemThe_TextChanged);
            this.txtTimKiemSach.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTimKiemThe_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(428, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 19);
            this.label8.TabIndex = 14;
            this.label8.Text = "Tìm kiếm sách";
            // 
            // txtSoLuongMuon
            // 
            this.txtSoLuongMuon.Location = new System.Drawing.Point(194, 159);
            this.txtSoLuongMuon.Name = "txtSoLuongMuon";
            this.txtSoLuongMuon.Size = new System.Drawing.Size(195, 26);
            this.txtSoLuongMuon.TabIndex = 13;
            this.txtSoLuongMuon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuongMuon_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(79, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 19);
            this.label7.TabIndex = 12;
            this.label7.Text = "Số lượng mượn";
            // 
            // cbTenSach
            // 
            this.cbTenSach.FormattingEnabled = true;
            this.cbTenSach.Location = new System.Drawing.Point(194, 73);
            this.cbTenSach.Name = "cbTenSach";
            this.cbTenSach.Size = new System.Drawing.Size(195, 27);
            this.cbTenSach.TabIndex = 10;
            this.cbTenSach.SelectedIndexChanged += new System.EventHandler(this.cbTenSach_SelectedIndexChanged);
            // 
            // cbMaSach
            // 
            this.cbMaSach.FormattingEnabled = true;
            this.cbMaSach.Location = new System.Drawing.Point(194, 25);
            this.cbMaSach.Name = "cbMaSach";
            this.cbMaSach.Size = new System.Drawing.Size(195, 27);
            this.cbMaSach.TabIndex = 9;
            this.cbMaSach.SelectedIndexChanged += new System.EventHandler(this.cbMaSach_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(428, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Ngày trả";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(428, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Ngày mượn";
            // 
            // dateTimeNT
            // 
            this.dateTimeNT.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeNT.Location = new System.Drawing.Point(544, 121);
            this.dateTimeNT.Name = "dateTimeNT";
            this.dateTimeNT.Size = new System.Drawing.Size(189, 26);
            this.dateTimeNT.TabIndex = 6;
            // 
            // dateTimeNM
            // 
            this.dateTimeNM.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeNM.Location = new System.Drawing.Point(544, 74);
            this.dateTimeNM.Name = "dateTimeNM";
            this.dateTimeNM.Size = new System.Drawing.Size(189, 26);
            this.dateTimeNM.TabIndex = 5;
            // 
            // cbTenTheLoai
            // 
            this.cbTenTheLoai.Enabled = false;
            this.cbTenTheLoai.FormattingEnabled = true;
            this.cbTenTheLoai.Location = new System.Drawing.Point(544, 25);
            this.cbTenTheLoai.Name = "cbTenTheLoai";
            this.cbTenTheLoai.Size = new System.Drawing.Size(189, 27);
            this.cbTenTheLoai.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(428, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tên thể loại";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mã thẻ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên sách";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã sách";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(35, 33);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(872, 554);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPage1.Controls.Add(this.btnDong);
            this.tabPage1.Controls.Add(this.btnXoaPhieuMuon);
            this.tabPage1.Controls.Add(this.btnChoMuon);
            this.tabPage1.Controls.Add(this.dataGridViewPM);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(864, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mượn sách";
            // 
            // dataGridViewPM
            // 
            this.dataGridViewPM.AllowUserToAddRows = false;
            this.dataGridViewPM.AllowUserToDeleteRows = false;
            this.dataGridViewPM.AllowUserToResizeColumns = false;
            this.dataGridViewPM.AllowUserToResizeRows = false;
            this.dataGridViewPM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column16});
            this.dataGridViewPM.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewPM.Location = new System.Drawing.Point(22, 267);
            this.dataGridViewPM.MultiSelect = false;
            this.dataGridViewPM.Name = "dataGridViewPM";
            this.dataGridViewPM.ReadOnly = true;
            this.dataGridViewPM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPM.Size = new System.Drawing.Size(816, 200);
            this.dataGridViewPM.TabIndex = 1;
            this.dataGridViewPM.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPM_CellClick);
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "MaPhieuMuon";
            this.Column7.HeaderText = "Mã PM";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "MaSach";
            this.Column1.HeaderText = "Mã sách";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "TenSach";
            this.Column2.HeaderText = "Tên sách";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "MaThe";
            this.Column3.HeaderText = "Mã thẻ";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "SoLuongMuon";
            this.Column4.HeaderText = "SL mượn";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "NgayMuon";
            this.Column5.HeaderText = "Ngày mượn";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "NgayTra";
            this.Column6.HeaderText = "Ngày trả";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "MaTT";
            this.Column16.HeaderText = "MaTT";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPage2.Controls.Add(this.btnDong1);
            this.tabPage2.Controls.Add(this.btnXoaPhieuTra);
            this.tabPage2.Controls.Add(this.btnTraSach);
            this.tabPage2.Controls.Add(this.dataGridViewPhieuTra);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(864, 528);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Trả sách";
            // 
            // dataGridViewPhieuTra
            // 
            this.dataGridViewPhieuTra.AllowUserToAddRows = false;
            this.dataGridViewPhieuTra.AllowUserToDeleteRows = false;
            this.dataGridViewPhieuTra.AllowUserToResizeColumns = false;
            this.dataGridViewPhieuTra.AllowUserToResizeRows = false;
            this.dataGridViewPhieuTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPhieuTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPhieuTra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column14,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column15,
            this.Column17});
            this.dataGridViewPhieuTra.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewPhieuTra.Location = new System.Drawing.Point(6, 255);
            this.dataGridViewPhieuTra.MultiSelect = false;
            this.dataGridViewPhieuTra.Name = "dataGridViewPhieuTra";
            this.dataGridViewPhieuTra.ReadOnly = true;
            this.dataGridViewPhieuTra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPhieuTra.Size = new System.Drawing.Size(852, 198);
            this.dataGridViewPhieuTra.TabIndex = 1;
            this.dataGridViewPhieuTra.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPhieuTra_CellClick);
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "MaPhieuTra";
            this.Column14.HeaderText = "Mã PT";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "MaDocGia";
            this.Column8.HeaderText = "Mã DG";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "MaThe";
            this.Column9.HeaderText = "Mã thẻ";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "MaSach";
            this.Column10.HeaderText = "Mã sách";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "SoLuongMuon";
            this.Column11.HeaderText = "SL mượn";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "SoLuongTra";
            this.Column12.HeaderText = "SL Trả";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "NgayTra";
            this.Column13.HeaderText = "Ngày trả";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "TinhTrangSach";
            this.Column15.HeaderText = "Tình trạng";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "MaTT";
            this.Column17.HeaderText = "MaTT";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.SkyBlue;
            this.groupBox2.Controls.Add(this.cbTinhTrangSach);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtSoLuongDaMuon);
            this.groupBox2.Controls.Add(this.txtSoLuongTra);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtMaPhieuTra);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtTimKiemTheTra);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.dateTimeNgayTra);
            this.groupBox2.Controls.Add(this.cbTenSachTra);
            this.groupBox2.Controls.Add(this.cbMaTheTra);
            this.groupBox2.Controls.Add(this.cbMaDocGia);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(29, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(809, 231);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trả sách";
            // 
            // cbTinhTrangSach
            // 
            this.cbTinhTrangSach.FormattingEnabled = true;
            this.cbTinhTrangSach.Items.AddRange(new object[] {
            "Tốt",
            "Xấu"});
            this.cbTinhTrangSach.Location = new System.Drawing.Point(202, 192);
            this.cbTinhTrangSach.Name = "cbTinhTrangSach";
            this.cbTinhTrangSach.Size = new System.Drawing.Size(180, 27);
            this.cbTinhTrangSach.TabIndex = 17;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(74, 195);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 19);
            this.label18.TabIndex = 16;
            this.label18.Text = "Tình trạng sách";
            // 
            // txtSoLuongDaMuon
            // 
            this.txtSoLuongDaMuon.Enabled = false;
            this.txtSoLuongDaMuon.Location = new System.Drawing.Point(202, 115);
            this.txtSoLuongDaMuon.Name = "txtSoLuongDaMuon";
            this.txtSoLuongDaMuon.Size = new System.Drawing.Size(180, 26);
            this.txtSoLuongDaMuon.TabIndex = 15;
            this.txtSoLuongDaMuon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuongDaMuon_KeyPress);
            // 
            // txtSoLuongTra
            // 
            this.txtSoLuongTra.Location = new System.Drawing.Point(202, 154);
            this.txtSoLuongTra.Name = "txtSoLuongTra";
            this.txtSoLuongTra.Size = new System.Drawing.Size(180, 26);
            this.txtSoLuongTra.TabIndex = 11;
            this.txtSoLuongTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuongTra_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(74, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 19);
            this.label15.TabIndex = 10;
            this.label15.Text = "Số lượng trả";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(74, 119);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(122, 19);
            this.label17.TabIndex = 14;
            this.label17.Text = "Số lượng đã mượn";
            // 
            // txtMaPhieuTra
            // 
            this.txtMaPhieuTra.Enabled = false;
            this.txtMaPhieuTra.Location = new System.Drawing.Point(519, 118);
            this.txtMaPhieuTra.Name = "txtMaPhieuTra";
            this.txtMaPhieuTra.Size = new System.Drawing.Size(267, 26);
            this.txtMaPhieuTra.TabIndex = 13;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(451, 121);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 19);
            this.label16.TabIndex = 12;
            this.label16.Text = "Mã PT";
            // 
            // txtTimKiemTheTra
            // 
            this.txtTimKiemTheTra.Location = new System.Drawing.Point(553, 160);
            this.txtTimKiemTheTra.Name = "txtTimKiemTheTra";
            this.txtTimKiemTheTra.Size = new System.Drawing.Size(233, 26);
            this.txtTimKiemTheTra.TabIndex = 9;
            this.txtTimKiemTheTra.TextChanged += new System.EventHandler(this.txtTimKiemTheTra_TextChanged);
            this.txtTimKiemTheTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTimKiemTheTra_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(451, 163);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 19);
            this.label14.TabIndex = 8;
            this.label14.Text = "Tìm kiếm sách";
            // 
            // dateTimeNgayTra
            // 
            this.dateTimeNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeNgayTra.Location = new System.Drawing.Point(519, 75);
            this.dateTimeNgayTra.Name = "dateTimeNgayTra";
            this.dateTimeNgayTra.Size = new System.Drawing.Size(267, 26);
            this.dateTimeNgayTra.TabIndex = 7;
            // 
            // cbTenSachTra
            // 
            this.cbTenSachTra.FormattingEnabled = true;
            this.cbTenSachTra.Location = new System.Drawing.Point(519, 24);
            this.cbTenSachTra.Name = "cbTenSachTra";
            this.cbTenSachTra.Size = new System.Drawing.Size(267, 27);
            this.cbTenSachTra.TabIndex = 6;
            this.cbTenSachTra.SelectedIndexChanged += new System.EventHandler(this.cbTenSachTra_SelectedIndexChanged);
            // 
            // cbMaTheTra
            // 
            this.cbMaTheTra.FormattingEnabled = true;
            this.cbMaTheTra.Location = new System.Drawing.Point(202, 70);
            this.cbMaTheTra.Name = "cbMaTheTra";
            this.cbMaTheTra.Size = new System.Drawing.Size(180, 27);
            this.cbMaTheTra.TabIndex = 5;
            this.cbMaTheTra.SelectedIndexChanged += new System.EventHandler(this.cbMaTheTra_SelectedIndexChanged);
            // 
            // cbMaDocGia
            // 
            this.cbMaDocGia.FormattingEnabled = true;
            this.cbMaDocGia.Location = new System.Drawing.Point(202, 28);
            this.cbMaDocGia.Name = "cbMaDocGia";
            this.cbMaDocGia.Size = new System.Drawing.Size(180, 27);
            this.cbMaDocGia.TabIndex = 4;
            this.cbMaDocGia.SelectedIndexChanged += new System.EventHandler(this.cbMaDocGia_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(450, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 19);
            this.label13.TabIndex = 3;
            this.label13.Text = "Ngày trả";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(450, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 19);
            this.label12.TabIndex = 2;
            this.label12.Text = "Tên sách";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(74, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 19);
            this.label11.TabIndex = 1;
            this.label11.Text = "Mã thẻ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "Mã đọc giả";
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Image = global::QuanLyThuVien.Properties.Resources.Knob_Cancel_icon;
            this.btnDong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDong.Location = new System.Drawing.Point(534, 473);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(86, 45);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // btnXoaPhieuMuon
            // 
            this.btnXoaPhieuMuon.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPhieuMuon.Image = global::QuanLyThuVien.Properties.Resources.Knob_Remove_Red_icon;
            this.btnXoaPhieuMuon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoaPhieuMuon.Location = new System.Drawing.Point(402, 473);
            this.btnXoaPhieuMuon.Name = "btnXoaPhieuMuon";
            this.btnXoaPhieuMuon.Size = new System.Drawing.Size(82, 45);
            this.btnXoaPhieuMuon.TabIndex = 4;
            this.btnXoaPhieuMuon.Text = "Xoá";
            this.btnXoaPhieuMuon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoaPhieuMuon.UseVisualStyleBackColor = true;
            this.btnXoaPhieuMuon.Click += new System.EventHandler(this.btnXoaPhieuMuon_Click);
            // 
            // btnChoMuon
            // 
            this.btnChoMuon.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChoMuon.Image = global::QuanLyThuVien.Properties.Resources.Knob_Add_icon;
            this.btnChoMuon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChoMuon.Location = new System.Drawing.Point(240, 473);
            this.btnChoMuon.Name = "btnChoMuon";
            this.btnChoMuon.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnChoMuon.Size = new System.Drawing.Size(114, 45);
            this.btnChoMuon.TabIndex = 3;
            this.btnChoMuon.Text = "Cho mượn";
            this.btnChoMuon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnChoMuon.UseVisualStyleBackColor = true;
            this.btnChoMuon.Click += new System.EventHandler(this.btnChoMuon_Click);
            // 
            // btnDong1
            // 
            this.btnDong1.Image = global::QuanLyThuVien.Properties.Resources.Knob_Cancel_icon;
            this.btnDong1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDong1.Location = new System.Drawing.Point(525, 468);
            this.btnDong1.Name = "btnDong1";
            this.btnDong1.Size = new System.Drawing.Size(91, 43);
            this.btnDong1.TabIndex = 3;
            this.btnDong1.Text = "Đóng";
            this.btnDong1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDong1.UseVisualStyleBackColor = true;
            this.btnDong1.Click += new System.EventHandler(this.btnDong1_Click);
            // 
            // btnXoaPhieuTra
            // 
            this.btnXoaPhieuTra.Image = global::QuanLyThuVien.Properties.Resources.Knob_Remove_Red_icon;
            this.btnXoaPhieuTra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoaPhieuTra.Location = new System.Drawing.Point(397, 468);
            this.btnXoaPhieuTra.Name = "btnXoaPhieuTra";
            this.btnXoaPhieuTra.Size = new System.Drawing.Size(80, 43);
            this.btnXoaPhieuTra.TabIndex = 3;
            this.btnXoaPhieuTra.Text = "Xoá";
            this.btnXoaPhieuTra.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoaPhieuTra.UseVisualStyleBackColor = true;
            this.btnXoaPhieuTra.Click += new System.EventHandler(this.btnXoaPhieuTra_Click);
            // 
            // btnTraSach
            // 
            this.btnTraSach.Image = global::QuanLyThuVien.Properties.Resources.Knob_Valid_Green_icon;
            this.btnTraSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTraSach.Location = new System.Drawing.Point(249, 468);
            this.btnTraSach.Name = "btnTraSach";
            this.btnTraSach.Size = new System.Drawing.Size(97, 43);
            this.btnTraSach.TabIndex = 2;
            this.btnTraSach.Text = "Trả sách";
            this.btnTraSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTraSach.UseVisualStyleBackColor = true;
            this.btnTraSach.Click += new System.EventHandler(this.btnTraSach_Click);
            // 
            // FrmMuonTraSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(935, 599);
            this.Controls.Add(this.tabControl1);
            this.Name = "FrmMuonTraSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Theo dõi mượn trả sách";
            this.Load += new System.EventHandler(this.FrmMuonTraSach_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPM)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPhieuTra)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimeNT;
        private System.Windows.Forms.DateTimePicker dateTimeNM;
        private System.Windows.Forms.ComboBox cbTenTheLoai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbTenSach;
        private System.Windows.Forms.ComboBox cbMaSach;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridViewPM;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnChoMuon;
        private System.Windows.Forms.Button btnXoaPhieuMuon;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.TextBox txtSoLuongMuon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTimKiemSach;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbMaThe;
        private System.Windows.Forms.TextBox txtMaPhieuMuon;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimeNgayTra;
        private System.Windows.Forms.ComboBox cbTenSachTra;
        private System.Windows.Forms.ComboBox cbMaTheTra;
        private System.Windows.Forms.ComboBox cbMaDocGia;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTimKiemTheTra;
        private System.Windows.Forms.DataGridView dataGridViewPhieuTra;
        private System.Windows.Forms.Button btnDong1;
        private System.Windows.Forms.Button btnXoaPhieuTra;
        private System.Windows.Forms.Button btnTraSach;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSoLuongTra;
        private System.Windows.Forms.TextBox txtMaPhieuTra;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSoLuongDaMuon;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbTinhTrangSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
    }
}
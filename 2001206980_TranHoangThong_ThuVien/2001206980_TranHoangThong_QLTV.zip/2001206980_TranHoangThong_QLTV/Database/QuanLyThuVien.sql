﻿Create Database QuanLyThuVien
go  
Use QuanLyThuVien
go 

Set Dateformat dmy
Create Table NhaXuatBan
(
	MaNXB int identity primary key not null,
	TenNXB nvarchar(50),
	DiaChi nvarchar(255),
	NgayThanhLap datetime,
)

Create Table ThuThu
(
    MaTT nvarchar(30) primary key not null,
	Hoten nvarchar(255),
	GioiTinh nvarchar(10),
	DiaChi nvarchar(255),
	NgaySinh datetime,
	SoDienThoai nvarchar(20),
)

Create Table TaiKhoan
(
	MaTK int identity primary key not null,
	TK nvarchar(50),
	MK varchar(50),
	MaTT nvarchar(30),
	Quyen nvarchar(10),
	foreign key (MaTT) references ThuThu(MaTT) on delete cascade
)

Create Table DocGia
(
	MaDocGia int identity primary key not null,
	Hoten nvarchar(255),
	GioiTinh nvarchar(10),
	DiaChi nvarchar(255),
	NgaySinh datetime,
	SoDienThoai nvarchar(20),
)

Create Table The
(
	MaThe nvarchar(50) primary key not null,
	MaDocGia int,
	NgayCapThe date,
	NgayHetHan date,
	MaTT nvarchar(30),
	foreign key (MaTT) references ThuThu(MaTT) on delete cascade,
	foreign key (MaDocGia) references DocGia(MaDocGia) on delete cascade
)

Create Table TheLoai
(
	MaTheLoai nvarchar(20) primary key not null,
	TenLoai nvarchar(50),
)

Create Table Sach
(
	MaSach int primary key identity not null,
	TenSach nvarchar(255),
	TacGia nvarchar(50),
	MaTheLoai nvarchar(20),
	MaNXB int,
	DonGia int,
	SoLuongTon int,
	SoLanMuon int,
	TinhTrang nvarchar(20),
	foreign key (MaTheLoai) references TheLoai(MaTheLoai) on delete cascade,
	foreign key (MaNXB) references NhaXuatBan(MaNXB) on delete cascade,
)

Create Table PhieuMuon
(
	MaPhieuMuon int identity primary key not null,
	MaSach int,
	TenSach nvarchar(50),
	MaThe nvarchar(50),
	MaTheLoai nvarchar(20),
	NgayMuon date,
	NgayTra date,
	SoLuongMuon int,
	MaTT nvarchar(30),
	foreign key (MaTT) references ThuThu(MaTT) on delete cascade,
	foreign key (MaSach) references Sach(MaSach) on delete cascade,
	foreign key (MaTheLoai) references TheLoai(MaTheLoai),
	foreign key (MaThe) references The(MaThe) 
)

Create Table PhieuTra
(
	MaPhieuTra int primary key identity not null,
	MaDocGia int,
	MaThe nvarchar(50),
	MaSach int,
	SoLuongMuon int,
	SoLuongTra int,
	NgayTra date,
	TinhTrangSach nvarchar(10),
	MaTT nvarchar(30),
	foreign key (MaTT) references ThuThu(MaTT) on delete cascade,
	foreign key (MaDocGia) references DocGia(MaDocGia) on delete cascade,
	foreign key (MaThe) references The(MaThe),
	foreign key (MaSach) references Sach(MaSach) on delete cascade,
)

Create Table QuyDinh
(
	MaQD int primary key identity not null,
	TenQD nvarchar (50),
	SoLuongQD int
)

Insert Into QuyDinh values(N'Số sách cho mượn tối đa',3)
Insert Into QuyDinh values(N'Số sách mượn nhiều nhất để thống kê',10)
Insert Into QuyDinh values(N'Độ tuổi cấp thẻ thư viện',18)

Insert Into ThuThu values('TT001', N'Trần Hoàng Thông',N'Nam', N'Quận 12', '22/08/2000', '0987656789')
Insert Into ThuThu values('TT002', N'Lê Xuân Trí',N'Nam', N'Quận Gò Vấp',' 22/08/1993', '0987656666')

Insert Into TaiKhoan values('thong', '123', 'TT001', 'User')
Insert Into TaiKhoan values('tri', '123', 'TT002', 'User')
Insert Into TaiKhoan values('admin', '123', null, 'Admin')

Insert Into DocGia values(N'Trịnh Thanh Bình', N'Nam', N'Quận 11', '22/10/2000', '0954586929')
Insert Into DocGia values(N'Trịnh Tùng Chiến', N'Nam', N'Quận Gò Vấp', '21/09/2000', '0876543211')
Insert Into DocGia values(N'Trần Hồ Thiên Phú', N'Nam', N'Huyện Bình Chánh', '01/01/2000', '0234567899')

Insert Into The values(N'T09828929',1,'22/10/2020','22/10/2023','TT001')
Insert Into The values(N'T01922211',2,'21/09/2020','21/09/2023','TT001')
Insert Into The values(N'T00332899',3,'01/01/2020','01/09/2023','TT001')

Insert Into NhaXuatBan values(N'Kim Đồng',N'55 Quang Trung, Nguyễn Du, Hai Bà Trưng, Hà Nội', '17/06/1957')
Insert Into NhaXuatBan values(N'RELX Group (Reed Elsevier)', N'Trụ sở Anh, Mỹ, Hà lan', '23/06/1930')
Insert Into NhaXuatBan values(N'Bertelsmann', N'Trụ sở Đức', '21/04/1835')

Insert Into TheLoai values(N'WB', N'WINGS BOOKS')
Insert Into TheLoai values(N'VHVN',  N'Văn học Việt Nam')
Insert Into TheLoai values(N'VHNN',N'Văn học nước ngoài')
Insert Into TheLoai values(N'TT', N'Truyện tranh')
Insert Into TheLoai values(N'KTKH', N'Kiến thức-khoa học')
Insert Into TheLoai values(N'GMBT', N'Giải mã bản thân')
Insert Into TheLoai values(N'TrT', N'Trinh thám')

Insert Into Sach values(N'Sức mạnh của sự cô đơn', N'Tokio Godo', 'WB', 1,68000, 100, 120, N'Tốt')
Insert Into Sach values(N'HOLMES Ở KYOTO', N'Mai  Mochizuki', 'WB', 1, 75000, 100, 55, N'Tốt')
Insert Into Sach values(N'Trường ca ACHILLES', N'Madeline Miller', 'WB', 1, 156000, 100, 33, N'Tốt')
Insert Into Sach values(N'Thị trấn mèo', N'Nekomaki',' WB', 1, 68000, 100, 11, N'Tốt')
Insert Into Sach values(N'Chuyện ma ám ở trang viên BLY', N'Henry James', 'WB', 1,60000, 100, 10, N'Tốt')
Insert Into Sach values(N'Dế mèn phiêu lưu ký', N'Tô Hoài-Tạ Huy Long', 'VHVN', 1, 150000, 100, 30, N'Tốt')
Insert Into Sach values(N'Chiếc gối biết nói', N'Phạm Thị Ngọc Liên', 'VHVN', 1,75000, 100, 40, N'Tốt')
Insert Into Sach values(N'Kính vạn hoa', N'Nguyễn Nhật Ánh', 'VHVN', 1, 99000, 100, 21, N'Tốt')
Insert Into Sach values(N'Học viện viễn thám - Hang hùm', N'Trudi Trueit', 'VHNN', 1, 125000, 100, 9, N'Tốt')
Insert Into Sach values(N'Peter Pan - Đứa bé không bao giờ lớn', N'J. M. Barrie', 'VHNN', 1,60000, 100, 22, N'Tốt')
Insert Into Sach values(N'Tý quậy', N'Đào Hải', 'TT', 1, 99000, 100, 24, N'Tốt')
Insert Into Sach values(N'Doanh nhân thế giới - FABRÊ', N'Han Kiên', 'TT', 1, 30000, 100, 44 ,N'Tốt')
Insert Into Sach values(N'SHIN - Cậu bé bút chì', N'Yoshito Usui', 'TT', 1, 20000, 100, 25, N'Tốt')
Insert Into Sach values(N'Thế giới xe công trình - Xe nâng cừ khôi', N'Mijika Liuzi', 'TT', 1, 26000, 100, 10, N'Tốt')
Insert Into Sach values(N'Mười vạn câu hỏi vì sao - Thưởng thức cuộc sống', N'Dư Diệu Đông', 'KTKH', 1, 40000, 100, 51, N'Tốt')
Insert Into Sach values(N'Tôi tin tôi có thể làm được - Học cách học tập', N'Chu Nam Chiếu - Tôn Vân Hiểu', 'KTKH', 1, 45000, 100, 80, N'Tốt')
Insert Into Sach values(N'Hồ sơ tính cách 12 con giáp', N'Nhóm Lovedia', 'GMBT', 1, 48000, 100, 12, N'Tốt')
Insert Into Sach values(N'Định hướng sự nghiệp theo chiêm tinh học', N'Nhóm Lovedia', 'GMBT', 1, 30000, 100, 12, N'Tốt')
Insert Into Sach values(N'Sự Im Lặng Của Bầy Cừu 1988', N'Nhóm Lovedia', 'TrT', 1, 35000, 100, 15, N'Tốt')
Insert Into Sach values(N'Mật Mã Da Vinci 2003',N'Dan Brown', 'TrT', 1, 38000, 100, 11, N'Tốt')
Insert Into Sach values(N'Án Mạng Trên Chuyến Tàu Tốc Hành Phương Đông 1934', N'Agatha Christie','TrT', 1, 46000, 100, 14, N'Tốt')